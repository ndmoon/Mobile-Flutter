var product = [
  [
    "T-Shirt",
    "./lib/assets/images/t-shirt.png",
    "Rp. 410000"
  ], //harus ditampung ke dlam array semua komponen
  ["Dress", "./lib/assets/images/dress.png", "Rp. 610000"],
  ["Jeans", "./lib/assets/images/jeans.png", "Rp. 310000"],
  ["Shoes", "./lib/assets/images/sneakers.png", "Rp. 230000"],
  ["Shirt", "./lib/assets/images/cloth.png", "Rp. 360000"],
  ["Hat", "./lib/assets/images/cap.png", "Rp. 110000"],
];

var cart = [];
